#include "my_vi.h"
#include <stdio.h>

int main(int argc,char *argv[])
{
	int ret;
	//ret = Vi_GetFrame();
	
	//VencGetFrame();
	//OSD_GetFrame();
	CaptureJPEG(2);
	return 0;
}