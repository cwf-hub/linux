#include "my_vi_func.h"

int CaptureJPEG(int num)
{
	XM_S32 s32Ret;
	VI_CHN ViChn = 0;
	VI_CHN jpegChn = 2;
	//系统初始化、ISP初始化
	s32Ret = SampleSysInit();
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("SampleSysInit failed!\n");
	}
	//VI通道设置、使能开启
	s32Ret = ViChnConfig(ViChn,VIDEO_ENCODING_MODE_PAL,CAPTURE_SIZE_720P);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("ViChnConfig failed!\n");
	}
	//VENC通道创建
	s32Ret = VencChnConfig(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("VencChnConfig failed!\n");
	}
	//JPEG通道创建
	s32Ret = JPEGChnConfig(jpegChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("JPEGChnConfig failed!\n");
	}
	//抓图
	s32Ret = JPEGCatch(num);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("JPEGCatch failed!\n");
	}
	//关闭编码通道
	s32Ret = XM_MPI_VENC_DestroyChn(jpegChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_DestroyChn failed!\n");
	}
	//失能VI通道
	s32Ret = XM_MPI_VI_DisableChn(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VI_DisableChn failed!\n");
	}
	//关闭ISP
	system("killall isp");
	return s32Ret;
}
int OSD_GetFrame(void)
{
	XM_S32 s32Ret;
	VI_CHN ViChn = 0;
	XM_U8 thePixel[] = {
		0x10,0x40,0x00,0x04,0x10,0xA0,0x47,0xFE,
        0x10,0x88,0x31,0x00,0xFD,0xFC,0x11,0x08,
        0x11,0x20,0x01,0xFC,0x13,0x28,0x01,0x08,
        0x25,0xFC,0xF1,0x08,0x21,0x20,0x11,0x08,
        0x51,0x28,0x11,0x08,0x51,0xFC,0x11,0x08,
        0x91,0x20,0x12,0x08,0x25,0x20,0x14,0x50,
        0x45,0x24,0x10,0x20,0x7D,0xFE,0x28,0x06,
        0x01,0x00,0x47,0xFC,0x01,0x00,0x00,0x00
	};
	COLOR_PARAM_S Color_Param = {
	.x = 10,
	.y = 10,
	.width = 32,
	.height = 16,
	.fg_color = 0x030303,
	.bg_color = 0xFFFFFF,
	.pixel = thePixel,
	};
	
	//系统、ISP初始化
	s32Ret = SampleSysInit();
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("SampleSysInit failed!\n");
	}
	
	//设置调色板
	RGN_PALLET_S rgn_Pallet = {{0x008080, 0x216EB9, 0x415BF1, 0x8235C1, 0xA21193,
	0x813623,0x19F16E, 0x5CB3B4,0x408080, 0x71488A, 0x4D9348, 0x9AA611, 0x179398, 0x4E93E7, 0x9BA5AF, 0xDB8080}};
	
	s32Ret = XM_MPI_RGN_SetPallet(0,&rgn_Pallet);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_RGN_SetPallet failed!\n");
	}
	//VI通道配置并使能
	ViChnConfig(0,VIDEO_ENCODING_MODE_PAL,CAPTURE_SIZE_720P);
	//VENC通道开启并使能
	s32Ret = VencChnConfig(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("VencChnConfig Failed!\n");
		return XM_FAILURE;
	}
	//OSD配置
	OSDConfig(&Color_Param);
	
	//开始接受编码图像
	s32Ret = XM_MPI_VENC_StartRecvPic(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_StartRecvPic %0x Failed!\n",s32Ret);
		return XM_FAILURE;
	}
	//保存成H264文件
	s32Ret = VencSaveToH264(ViChn,5);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("VencSaveToH264 Failed!\n");
		return XM_FAILURE;
	}
	//停止VENC接收
	s32Ret = XM_MPI_VENC_StopRecvPic(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_StopRecvPic Failed!\n");
		return XM_FAILURE;
	}
	//失能VI
	s32Ret = XM_MPI_VI_DisableChn(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VI_DisableChn Failed!\n");
		return XM_FAILURE;
	}
		TEST_PRT("End!\n");
	//kill ISP
	system("killall isp");
	return 0;
}
int Vi_GetFrame(void)
{
	XM_S32 s32Ret;
	//系统初始化
	s32Ret = SampleSysInit();
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("SampleSysInit failed!\n");
	}
	//VI通道0配置并开启
	ViChnConfig(0,VIDEO_ENCODING_MODE_PAL,CAPTURE_SIZE_720P);
	//获取VI图像帧
	Vi_GetFrameAndSaveToFile();
	//关闭VI通道
	 XM_MPI_VI_DisableChn(0);
	//关闭ISP
	system("killall isp");
	return 0;
}

XM_S32 JPEGCatch(XM_S32 jpeg_num)
{
	XM_S32 s32Ret,count,i;
	VENC_STREAM_S stStream;
	VENC_STREAM_S *pstStream = &stStream;
	FILE *pFile[jpeg_num];
	XM_CHAR aFileName[jpeg_num][64];
	for(i = 0;i < jpeg_num;i++)
	{
		sprintf(aFileName[i],"%d.jpeg",i);
		pFile[i] = fopen(aFileName[i],"w+");
	}
	//开始接收图像
	s32Ret = XM_MPI_VENC_StartRecvPic(2);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_StartRecvPic jpeg failed!\n");
	}
	pstStream->pstPack = (VENC_PACK_S *)malloc(sizeof(VENC_PACK_S));
	if(NULL == pstStream->pstPack)
	{
		TEST_PRT("malloc failed!\n");
		return XM_FAILURE;
	}	
	for(count = 0;count < jpeg_num ;count++)
	{
		sleep(1);
		//获取数据流
		s32Ret = XM_MPI_VENC_GetStream(2,pstStream, XM_TRUE);
		if (XM_SUCCESS != s32Ret) 
        {
            TEST_PRT("XM_MPI_VENC_GetStream failed!\n");
			return XM_FAILURE;
        }
		//保存文件
		for(i = 0;i < pstStream->u32PackCount; i++)
		{
			fwrite(pstStream->pstPack[i].pu8Addr,pstStream->pstPack[i].u32Len,1,pFile[count]);
			fflush(pFile[count]);
		}
		fclose(pFile[count]);
		//释放数据流
		s32Ret = XM_MPI_VENC_ReleaseStream(2,pstStream);
		if (XM_SUCCESS != s32Ret) 
		{
			TEST_PRT("XM_MPI_VENC_ReleaseStream failed!\n");
		}	
	}
		//停止接收图像
		s32Ret = XM_MPI_VENC_StopRecvPic(2);
		if (XM_SUCCESS != s32Ret) 
		{
			TEST_PRT("XM_MPI_VENC_StopRecvPic failed!\n");
		}
		free(pstStream->pstPack);
		return s32Ret;
}

XM_S32 JPEGChnConfig(VI_CHN ViChn)
{
	XM_S32 s32Ret;
	VENC_CHN_ATTR_S venc_Chn_Attr;
	venc_Chn_Attr.stVeAttr.enType = PT_JPEG;
	venc_Chn_Attr.stVeAttr.stAttrJpeg.u32MaxPicWidth = 1280;
	venc_Chn_Attr.stVeAttr.stAttrJpeg.u32MaxPicHeight = 720;
	venc_Chn_Attr.stVeAttr.stAttrJpeg.u32BufSize = 1280*720*3/2;
	venc_Chn_Attr.stVeAttr.stAttrJpeg.bByFrame = XM_TRUE;/*get stream mode is field mode  or frame mode*/
	venc_Chn_Attr.stVeAttr.stAttrJpeg.u32PicWidth = 1280;
	venc_Chn_Attr.stVeAttr.stAttrJpeg.u32PicHeight = 720;
	//venc_Chn_Attr.stVeAttr.stAttrJpeg.bSupportDCF = XM_FALSE;
	
	s32Ret =XM_MPI_VENC_CreateChn(ViChn,&venc_Chn_Attr);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_CreateChn jpeg failed!\n");
	}
	TEST_PRT("XM_MPI_VENC_CreateChn jpeg success!\n");
	return s32Ret;
}

XM_S32 OSDConfig(COLOR_PARAM_S *pParam)
{
	XM_S32 s32Ret;
	RGN_ATTR_S rgn_Attr;
	BITMAP_S bitMap;
	XM_S32 RgnHandle = 0;//区域句柄号
	VI_CHN ViChn = 0;
	rgn_Attr.u32Handle = RgnHandle;//区域句柄号
	rgn_Attr.enType = OVERLAY_RGN;//区域类型，叠加型
	rgn_Attr.unAttr.stOverlay.u32ColorMap = 0XF0;//颜色
	rgn_Attr.unAttr.stOverlay.u32Effect = (pParam->bg_color >> 30);
	rgn_Attr.unAttr.stOverlay.u32Format = 0;//特殊效果
	rgn_Attr.unAttr.stOverlay.stRect.s32X = pParam->x;
	rgn_Attr.unAttr.stOverlay.stRect.s32Y = pParam->y;
	rgn_Attr.unAttr.stOverlay.stRect.u32Width = pParam->width/2;
	rgn_Attr.unAttr.stOverlay.stRect.u32Height = pParam->height/2;
	
	s32Ret = XM_MPI_RGN_Create(ViChn,&rgn_Attr);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_RGN_Create failed!\n");
	}
	TEST_PRT("XM_MPI_RGN_Create success!\n");
	
	bitMap.u32Handle	= RgnHandle;//区域句柄号
	bitMap.u32Width		= pParam->width;//位图宽度
	bitMap.u32Height	= pParam->height;//位图高度
	bitMap.u32Format	= 0;//单色前景
	bitMap.pData		= (XM_VOID *)pParam->pixel;//位图数据
	
	//设置区域位图
	
	s32Ret = XM_MPI_RGN_SetBitMap(ViChn,&bitMap);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_RGN_SetBitMap failed!\n");
	}
	TEST_PRT("XM_MPI_RGN_SetBitMap success!\n");
	
	//显示区域位图
	XM_MPI_RGN_Enable(ViChn,RgnHandle,OVERLAY_RGN);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_RGN_Enable failed!\n");
	}
	TEST_PRT("XM_MPI_RGN_Enable success!\n");
	
	
	return s32Ret;
}

XM_S32 Vi_GetFrameAndSaveToFile(void)
{
	XM_S32 s32Ret,i;
	XM_S32 cnt = 1;
	VIDEO_FRAME_INFO_S st_Frame_Info;
	memset(&st_Frame_Info,0,sizeof(VIDEO_FRAME_INFO_S));
	XM_U32 getU32PhyAddr[2];
	XM_VOID *pVirAddr_Y;
	XM_VOID *pVirAddr_UV;
	s32Ret = XM_MPI_VI_GetFrame(0,&st_Frame_Info);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VI_GetFrame failed!\n");
	}
		//原始图像帧结构
	//TEST_PRT("st_Frame_Info.stVFrame.u32PhyAddr0 is %0x\n",st_Frame_Info.stVFrame.u32PhyAddr[0]);
	//TEST_PRT("st_Frame_Info.stVFrame.u32PhyAddr1 is %0x\n",st_Frame_Info.stVFrame.u32PhyAddr[1]);	
	
	getU32PhyAddr[0] = st_Frame_Info.stVFrame.u32PhyAddr[0];
	getU32PhyAddr[1] = st_Frame_Info.stVFrame.u32PhyAddr[1];
	
	pVirAddr_Y = XM_MPI_SYS_Mmap(getU32PhyAddr[0],1280*720 *3/2);
	
	s32Ret = XM_MPI_VI_ReleaseFrame(0,&st_Frame_Info);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VI_ReleaseFrame failed!\n");
	}
	FILE *pFile[VI_MAX_CHN_NUM];
	XM_CHAR aszFileName[VI_MAX_CHN_NUM][64];
	for(i = 0;i<1;i++)
	{
		sprintf(aszFileName[i], "YUV_frame%d",i);
		pFile[i] = fopen(aszFileName[i],"wb");
		if(!pFile[i])
		{
			TEST_PRT("open pFile[%d] failed!\n",i);
			fclose(pFile[i]);
		}
	}
	cnt = 25;
	//释放VI图像所占的缓存
	while(cnt--)
	{
		s32Ret = XM_MPI_VI_GetFrame(0,&st_Frame_Info);
		if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VI_GetFrame %0x failed!\n",s32Ret);
	}
		pVirAddr_Y = XM_MPI_SYS_Mmap(st_Frame_Info.stVFrame.u32PhyAddr[0],1280*720*3/2);
		if(pVirAddr_Y == 0)
	{
		TEST_PRT("XM_MPI_SYS_Mmap_Y failed!\n");
	}
		fwrite(pVirAddr_Y,1280*720*3/2,1,pFile[0]);
				
		s32Ret = XM_MPI_VI_ReleaseFrame(0,&st_Frame_Info);
		if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VI_ReleaseFrame failed!\n");
	}
		usleep(10);
	}
	
	fclose(pFile[0]);
	return s32Ret;
}

int VencGetFrame(void)
{
	XM_S32 s32Ret;
	XM_S32 ViChn = 0;
	XM_S32 VencChn = 0;
	//系统初始化
	s32Ret = SampleSysInit();
	if (XM_SUCCESS != s32Ret)
	{
		TEST_PRT("SampleSysInit failed!\n");
		return XM_FAILURE;
	}
	//VI通道配置
	s32Ret = ViChnConfig(ViChn,VIDEO_ENCODING_MODE_PAL,CAPTURE_SIZE_720P);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("ViChnConfig Failed!\n");
		return XM_FAILURE;
	}
	//VENC通道配置、开启
	s32Ret = VencChnConfig(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("VencChnConfig Failed!\n");
		return XM_FAILURE;
	}
	//开始编码接收图像
	s32Ret = XM_MPI_VENC_StartRecvPic(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_StartRecvPic %0x Failed!\n",s32Ret);
		return XM_FAILURE;
	}
	//保存成H264文件，5秒
	s32Ret = VencSaveToH264(ViChn,5);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("VencSaveToH264 Failed!\n");
		return XM_FAILURE;
	}
	//停止接收图像
	s32Ret = XM_MPI_VENC_StopRecvPic(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_StopRecvPic Failed!\n");
		return XM_FAILURE;
	}
	//关闭编码通道
	s32Ret = XM_MPI_VENC_DestroyChn(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VENC_DestroyChn Failed!\n");
		return XM_FAILURE;
	}
	//失能VI通道
	s32Ret = XM_MPI_VI_DisableChn(ViChn);
	if(XM_SUCCESS != s32Ret)
	{
		TEST_PRT("XM_MPI_VI_DisableChn Failed!\n");
		return XM_FAILURE;
	}
		TEST_PRT("End!\n");
	//关闭ISP
	system("killall isp");
	return 0;
}

XM_S32 VencSaveToH264(VENC_CHN ViChn,int seconds)
{
	XM_S32 s32Ret,i,cnt;
	VENC_STREAM_S venc_Stream;
	VENC_STREAM_S *pVenc_Stream = &venc_Stream;
	pVenc_Stream->pstPack = (VENC_PACK_S*)malloc(sizeof(VENC_PACK_S));
	FILE *pFile;
	XM_CHAR aFile_Name[64];
	//打开文件
	sprintf(aFile_Name,"yuv_frame");
	pFile = fopen(aFile_Name,"wb");
	if(!pFile)
	{
		TEST_PRT("fopen yuv_frame failed!\n");
		return XM_FAILURE;
	}
	TEST_PRT("Start Save...!\n");
	cnt = 25;
	while(cnt--)
	{
		//检查编码通道是否有数据
		s32Ret = XM_MPI_VENC_SelectData();
		if(XM_SUCCESS != s32Ret)
		{
			TEST_PRT("XM_MPI_VENC_SelectData Failed!\n");
			return XM_FAILURE;
		}
		//获取编码源数据流
		s32Ret = XM_MPI_VENC_GetStream(ViChn,pVenc_Stream,XM_FALSE);
		if(XM_SUCCESS != s32Ret)
		{
			TEST_PRT("XM_MPI_VENC_GetStream failed!\n");
			return XM_FAILURE;
		}
		//写入文件中
		for(i = 0;i < pVenc_Stream->u32PackCount; i++)
		{
			s32Ret = fwrite(pVenc_Stream->pstPack[i].pu8Addr,pVenc_Stream->pstPack[i].u32Len,1,pFile);
				if(s32Ret < 0)
			{
				TEST_PRT("fwrite failed!\n");
				//return XM_FAILURE;
			}
			fflush(pFile);
		}
		//释放编码内存
		s32Ret = XM_MPI_VENC_ReleaseStream(ViChn,pVenc_Stream);
		if(XM_SUCCESS != s32Ret)
		{
			TEST_PRT("XM_MPI_VENC_ReleaseStream failed!\n");
			return XM_FAILURE;
		}
	}
	
	fclose(pFile);
	free(pVenc_Stream->pstPack);
	//usleep(10);
	return s32Ret;
}
XM_S32 VencChnConfig(XM_S32 Vichn)
{
	XM_S32 s32Ret;
	VENC_CHN_ATTR_S venc_Chn_Attr;
	venc_Chn_Attr.stVeAttr.enType = PT_H264;
	venc_Chn_Attr.stVeAttr.stAttrH264e.u32MaxPicWidth = 1280;
	venc_Chn_Attr.stVeAttr.stAttrH264e.u32MaxPicHeight = 720;
	venc_Chn_Attr.stVeAttr.stAttrH264e.u32BufSize = 1280*720*3/8;
	venc_Chn_Attr.stVeAttr.stAttrH264e.u32Profile = 1;/*0: baseline; 1:MP; 2:HP   ? */
	venc_Chn_Attr.stVeAttr.stAttrH264e.bByFrame = XM_TRUE;/*XM_TRUE： 按帧获取。XM_FALSE： 按包获取。*/
	venc_Chn_Attr.stVeAttr.stAttrH264e.u32PicWidth = 1280;
	venc_Chn_Attr.stVeAttr.stAttrH264e.u32PicHeight = 720;
	//venc_Chn_Attr.stVeAttr.stAttrH264e.u32BFrameNum 保留状态
	//venc_Chn_Attr.stVeAttr.stAttrH264e.u32RefNum 保留状态
	
	venc_Chn_Attr.stRcAttr.enRcMode = VENC_RC_MODE_H264CBR;
	venc_Chn_Attr.stRcAttr.stAttrH264Cbr.u32Gop = 25;//组
	venc_Chn_Attr.stRcAttr.stAttrH264Cbr.u32StatTime = 1;//码率计算时间
	venc_Chn_Attr.stRcAttr.stAttrH264Cbr.u32SrcFrmRate = 25;
	venc_Chn_Attr.stRcAttr.stAttrH264Cbr.fr32DstFrmRate = 25;
	venc_Chn_Attr.stRcAttr.stAttrH264Cbr.u32BitRate = 1024;//平均压缩编码速度，kb
	venc_Chn_Attr.stRcAttr.stAttrH264Cbr.u32FluctuateLevel = 1;//最大码率对应平均码率波动等级
	
	s32Ret = XM_MPI_VENC_CreateChn(Vichn, &venc_Chn_Attr);
    if (XM_SUCCESS != s32Ret)
    {
        TEST_PRT("XM_MPI_VENC_CreateChn [%d] faild with %#x!\n",Vichn, s32Ret);
        return s32Ret;
    }
	return s32Ret;
}
XM_S32 SampleSysInit(void)
{
    static int sys_inited = 0;

    if(sys_inited == 0)
    {
        XM_MPI_SYS_Init();	
		int size = 1;
		char isp[128] = {0};
		snprintf(isp, 128, "isp -v %c -e %d -r %d &", 'p', 0, size);
		printf("%s\n", isp);
		system(isp);

        sys_inited = 1;
    }

	return XM_SUCCESS;
}

XM_S32 ViChnConfig(VI_CHN vi_chn,VIDEO_NORM_E enNorm,XM_U32 enSize)
{
	VI_CHN_ATTR_S vi_Chn_Attr_S;
	XM_S32 chnAttrRet = -1;
	memset(&vi_Chn_Attr_S,0,sizeof(VI_CHN_ATTR_S));
	vi_Chn_Attr_S.stCapRect.s32X = 0;
	vi_Chn_Attr_S.stCapRect.s32Y = 0;
	vi_Chn_Attr_S.stCapRect.u32Width = 1280;
	vi_Chn_Attr_S.stCapRect.u32Height = 720;
	vi_Chn_Attr_S.stDestSize.u32Width = 1280;
	vi_Chn_Attr_S.stDestSize.u32Height = 720;
	vi_Chn_Attr_S.enCapSel = VI_CAPSEL_BOTH;//逐行显示
	vi_Chn_Attr_S.enPixFormat = PIXEL_FORMAT_YUV_SEMIPLANAR_420;//图像格式yuv_sp420
	vi_Chn_Attr_S.bMirror = XM_FALSE;//是否水平翻转
	vi_Chn_Attr_S.bFlip = XM_FALSE;//是否垂直翻转
	vi_Chn_Attr_S.bChromaResample = XM_FALSE;//是否进行色度重采样，只对主通道有效
	vi_Chn_Attr_S.s32SrcFrameRate = 25;
	vi_Chn_Attr_S.s32FrameRate = 25;
	
	chnAttrRet = XM_MPI_VI_SetChnAttr(vi_chn,&vi_Chn_Attr_S);
	if(0 != chnAttrRet)
	{
		printf("XM_MPI_VI_SetChnAttr FAILURE!\n");
		return XM_FAILURE;
	}	
	/*使能开启通道*/	
	if(0 != XM_MPI_VI_EnableChn(vi_chn))
	{
		printf("XM_MPI_VI_EnableChn FAILURE!\n");
		return XM_FAILURE;
	}
		return 0;
}