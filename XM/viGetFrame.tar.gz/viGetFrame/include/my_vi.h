extern int ViGetFrame(void);
extern int VencGetFrame(void);
extern int OSD_GetFrame(void);
extern int CaptureJPEG(int num);