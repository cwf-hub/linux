#include "xm_type.h"
#include "xm_comm_sys.h"
#include "mpi_sys.h"
#include "xm_comm_vi.h"
#include "mpi_vi.h"
#include "DVRAPI.h"
#include "mpi_venc.h"
#include "xm_comm_venc.h"
#include "xm_comm_rc.h"
#include "xm_common.h"
#include "pthread.h"
#include "xm_comm_region.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/*
配置isp 需要宏定义SOC_XMSDK
*/
#ifndef SOC_XMSDK
#define SOC_XMSDK
#endif
/*
需要先定义宏SOC_XMSDK
*/
#include "Camera.h"

#define TEST_PRT(fmt...) \
	do{\
	printf("[%s]-%d: ", __FUNCTION__, __LINE__);\
	printf(fmt);\
	}while(0)

typedef struct color_param 
{
	XM_U16	x;
	XM_U16	y;		 
	XM_U16	width;
	XM_U16	height;
	XM_U32	fg_color;					/*!< text color, rgba 8:8:8:8 */
	XM_U32	bg_color;					/*!< background color, rgba 8:8:8:8 */
	XM_U8 	*pixel;
}COLOR_PARAM_S;
#define VI_MAX_CHN_NUM 4